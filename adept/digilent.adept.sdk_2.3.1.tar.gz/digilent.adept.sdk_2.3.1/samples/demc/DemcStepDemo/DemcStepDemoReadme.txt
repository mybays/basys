Module Description: 		
	DEMC Step Demo is a project that demonstrates how to
	control a stepper motor using an I/O Explorer board and
	the DEMC module of the Adept SDK.	

Hardware Setup:
	Connect the stepper motor to the PmodOD1 as described in the documentation.
	Connect the PmodOD1 to pins 7-10 of JA on the I/O Explorer.